package com.cg.frs.dao;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;
import com.cg.frs.ui.Client;

public class FlatRegistrationDAOImplTest {
	private IFlatRegistrationDAO flatDAOTest = new FlatRegistrationDAOImpl();
/*
 * test case to check valid owner is 
 */
	@Test
	public void testRegisterFalt() {
		FlatRegistrationDTO flat = new FlatRegistrationDTO(1001L,4,1,650,1000.00,6000.00);
		try {
			flatDAOTest.registerFalt(flat);
		} catch (FlatRegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
/**
 * test case to check valid owner ids
 */
	@Test
	public void testGetOwnerIds() {
		ArrayList<Integer> list =new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		try {
			flatDAOTest.getOwnerIds().contains(list);
		} catch (FlatRegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
