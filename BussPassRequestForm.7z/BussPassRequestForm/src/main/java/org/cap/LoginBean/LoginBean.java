package org.cap.LoginBean;

public class LoginBean {

}
