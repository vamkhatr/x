package org.cap.LoginBean;

import java.sql.Time;
import java.time.LocalDate;

public class BusBean {
	private String empId;
	private String firstName;
	private String lastName;
	private String gender;
	private String address;
	private LocalDate doj;
	private String email;
	private String location;
	private Time pickup;
	public BusBean(String empId, String firstName, String lastName, String gender, String address, LocalDate doj,
			String email, String location, Time pickup) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.doj = doj;
		this.email = email;
		this.location = location;
		this.pickup = pickup;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Time getPickup() {
		return pickup;
	}
	public void setPickup(Time pickup) {
		this.pickup = pickup;
	}

	
}
